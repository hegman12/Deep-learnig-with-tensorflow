from flask import Flask, render_template, request, send_file, redirect
import base64
import numpy as np
import libs.visualize as visualize
import scipy.misc as misc

from PIL import Image
import io

app=Flask(__name__)

def serve_pil_image(pil_img):
    img_io = io.BytesIO()
    pil_img.save(img_io, 'JPEG', quality=70)
    img_io.seek(0)
    return send_file(img_io, mimetype='image/jpeg')

@app.route("/")
def root():
    return home()

@app.route("/home")
def home():
    return render_template("home.html")

@app.route("/analyse")
def analyse():
    return render_template("analyze.html")

@app.route("/results",methods = ['POST'])
def results():
    formdata=request.form.to_dict()
    comma_index=formdata["data"].find(",")
    image_data=base64.decodebytes(formdata["data"][comma_index+1:].encode())
    image = Image.open(io.BytesIO(image_data))
    del image_data
    image = misc.imresize(arr=np.asarray(image,np.uint8),size=(299,299,3),interp="nearest")
    (accts,names),image=visualize.get_n_patterns(formdata["models"],image,int(formdata["topk"]))
    #return serve_pil_image(image)
    return render_template("results.html",images=enumerate(accts),file_urls=names,img=formdata["data"])

@app.route("/analyse_results",methods = ['POST'])
def analyse_results():
    formdata=request.form.to_dict()

    comma_index=formdata["image1"].find(",")
    image_data=base64.decodebytes(formdata["image1"][comma_index+1:].encode())
    image1 = Image.open(io.BytesIO(image_data))
    del image_data

    image1 = misc.imresize(arr=np.asarray(image1,np.uint8),size=(299,299,3),interp="nearest")

    comma_index=formdata["image2"].find(",")
    image_data=base64.decodebytes(formdata["image2"][comma_index+1:].encode())
    image2 = Image.open(io.BytesIO(image_data))
    del image_data
    image2 = misc.imresize(arr=np.asarray(image2,np.uint8),size=(299,299,3),interp="nearest")

    (common_patterns,image_1_patterns,image_2_patterns,file_urls)=visualize.compare_2_images(formdata["models"],image1,image2,int(formdata["topk"]))
    #return serve_pil_image(image)
    return render_template("analyse_results.html",file_urls=enumerate(file_urls),img1=formdata["image1"],img2=formdata["image2"],common_patterns=common_patterns,image_1_patterns=image_1_patterns,image_2_patterns=image_2_patterns)

if __name__=="__main__":
  app.run(debug=True)
