import imageio as iio
import numpy as np
import tensorflow as tf
import scipy.misc as misc
from libs.showing import image

import lucid.modelzoo.vision_models as models

def get_model(model_name):

    if model_name=="InceptionV1":
        v1=models.InceptionV1_slim()
        v1.load_graphdef()
    elif model_name=="InceptionV3":
        v1=models.InceptionV3_slim()
        v1.load_graphdef()

    else:
        raise ValueError("Currently this model is not supported")

    return v1

def T(layer,graph):
    return graph.get_tensor_by_name(layer+":0")

def tf_graph(lucid_model,graph,topk):
    g=[]
    for l in lucid_model.layers:
        op=graph.get_operation_by_name('import/'+l['name'])
        if l['type']=='conv':
            g.append(tf.nn.top_k(tf.reduce_sum(input_tensor=T('import/'+l['name'],graph),axis=(1,2)),k=topk))
    return g

def get_indices(topk_array):
    ret=[]
    for ka in topk_array:
        ret.append(ka.indices.ravel())
    return np.stack(ret)

def run(lucid_model,input_image,topk):
    graph=tf.Graph()
    with graph.as_default():
        tf.import_graph_def(lucid_model.graph_def)
    with tf.Session(graph=graph) as s:
        g=tf_graph(lucid_model,graph,topk)
        ret_g=s.run(g,feed_dict={T('import/'+lucid_model.input_name,graph):np.reshape(input_image,(1,299,299,3))})
        #print(i[0,0,0,:])
    return get_indices(ret_g)

def convert_and_get_images(ind,file_urls,topk):

    base64_images=[]
    base_url="D:\\InceptionV3\\spritemap\\"

    for i,file_url in enumerate(file_urls):
        ifile=np.load(file=base_url+file_url,mmap_mode='r')
        _base64_images=[]
        for idx in range(topk):
            _base64_images.append(image(ifile[idx]))
        base64_images.append(_base64_images)
        del ifile
    return base64_images,file_urls

def get_n_patterns(model_name,input_image,topk=3):
    model=get_model(model_name)
    indexes = run(model,input_image,topk)

    fnames=["InceptionV3_InceptionV3_Mixed_5b_concat_v2.npy","InceptionV3_InceptionV3_Mixed_5c_concat_v2.npy","InceptionV3_InceptionV3_Mixed_5d_concat_v2.npy","InceptionV3_InceptionV3_Mixed_6a_concat_v2.npy","InceptionV3_InceptionV3_Mixed_6b_concat_v2.npy","InceptionV3_InceptionV3_Mixed_6c_concat_v2.npy","InceptionV3_InceptionV3_Mixed_6d_concat_v2.npy"]

    return convert_and_get_images(indexes,fnames,topk),image(input_image)

def analyze_2_images(ind1,ind2,file_urls,topk):
    base_url="D:\\InceptionV3\\spritemap\\"

    common_patterns=[]
    image_1_patterns=[]
    image_2_patterns=[]
    print(ind1)
    print(ind2)
    for i,layer_idx in enumerate(ind1):
        ifile=np.load(file=base_url+file_urls[i],mmap_mode='r')
        _common_patterns=[]
        _image_1_patterns=[]
        _image_2_patterns=[]
        for neuron_index in layer_idx:
            if neuron_index in ind2[i]:
                _common_patterns.append(image(ifile[neuron_index]))
            else:
                _image_1_patterns.append(image(ifile[neuron_index]))

        for neuron_index in ind2[i]:
            if neuron_index not in layer_idx:
                _image_2_patterns.append(image(ifile[neuron_index]))
        common_patterns.append(_common_patterns)
        image_1_patterns.append(_image_1_patterns)
        image_2_patterns.append(_image_2_patterns)

        del ifile

    return common_patterns,image_1_patterns,image_2_patterns,file_urls

def compare_2_images(model_name,input_image1,input_image2,topk):
    model=get_model(model_name)
    image1_indexes = run(model,input_image1,topk)
    image2_indexes = run(model,input_image2,topk)

    fnames=["InceptionV3_InceptionV3_Mixed_5b_concat_v2.npy","InceptionV3_InceptionV3_Mixed_5c_concat_v2.npy","InceptionV3_InceptionV3_Mixed_5d_concat_v2.npy","InceptionV3_InceptionV3_Mixed_6a_concat_v2.npy","InceptionV3_InceptionV3_Mixed_6b_concat_v2.npy","InceptionV3_InceptionV3_Mixed_6c_concat_v2.npy","InceptionV3_InceptionV3_Mixed_6d_concat_v2.npy"]

    return analyze_2_images(image1_indexes,image2_indexes,fnames,topk)
