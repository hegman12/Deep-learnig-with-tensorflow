Models imported from caffe.

See `lucid/scripts/import_caffe/` for details on how to import more.
