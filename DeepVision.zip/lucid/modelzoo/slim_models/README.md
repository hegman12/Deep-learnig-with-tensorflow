Models imported from tf-slim's [pre-trained models](https://github.com/tensorflow/models/tree/master/research/slim#pre-trained-models).

See `lucid/scripts/import_slim/` for details on how to import more.
