# lucid.recipes

Less general code for doing particular things, like making a single
visualization.
