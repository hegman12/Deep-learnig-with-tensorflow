# lucid.misc

Mature code that doesn't fit into a large cluster.
