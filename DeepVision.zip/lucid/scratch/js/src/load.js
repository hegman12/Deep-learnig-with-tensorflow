// Copyright 2018 The Lucid Authors.All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0(the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ==============================================================================

import { csvParse, tsvParse } from 'd3-dsv';


// // Basic usage examples: 
// import {load} from 'lucid-components';
// 
// load("test.csv").then(response => console.log("1", response));
// load(["test.csv", "test.tsv"]).then(response => console.log("2", response[0], response[1]));
// load('3a.jpg').then(response => {this.refs.img.src = response.src;})
// 
// // You can also namespace requests, which will cancel previous requests
// load("test.csv", "namespace").then(response => console.log("This will never be called."))
// load("test.tsv", "namespace").then(response => console.log("This will interrupt the previous one and be resolved instead."))



// We will cache requests and parsing.
const cache = new Map();
const suppress = new Map();
const namespaces = new Map();

// Mapping file extensions to loaders
const loaders = new Map([
  ['gif', image],
  ['png', image],
  ['jpeg', image],
  ['jpg', image],
  ['csv', csv],
  ['tsv', tsv],
  ['txt', text],
  ['text', text],
  ['json', json],
]);

// Loaders
function handleErrors(response) {
  if (response.ok) {
    return response;
  } else {
    throw new Error(response.status + ':' + response.statusText);
  }
}

function image(url) {
  return new Promise((resolve, reject) => {
    let img = new Image();
    img.onload = event => resolve(img);
    img.onerror = event => reject(event);
    img.src = url;
  })
}

function json(url) {
  return fetch(url).then(handleErrors).then(response => response.json())
}

function text(url) {
  return fetch(url).then(handleErrors).then(response => response.text());
}

function csv(url) {
  return text(url).then(text => Promise.resolve(csvParse(text)));
}

function tsv(url) {
  return text(url).then(text => Promise.resolve(tsvParse(text)));
}


// Load a url or an array of urls.
function load(url, namespace) {

  // We will to create a namespace if we don't have one.
  let ns = namespace != null ? namespace : Date.now() + "" + Math.random();

  // Create a unique ID for this request
  let requestID = "namespace:" + ns + ", url:" + url + ", random:" + Date.now() + "" + Math.random();
  suppress.set(requestID, false);

  // If we have a previous request in this namespace, mark it as suppressed so 
  // that the promise is never resolved. Then we reset the current namespace to 
  // the current request.
  if (namespaces.has(ns)) {
    const pendingRequestID = namespaces.get(ns);
    suppress.set(pendingRequestID, true);
  }
  namespaces.set(ns, requestID);
  
  return new Promise((resolve, reject) => {
    let p;
    if (Array.isArray(url)) {
      const promises = url.map(u => _loadURL(u));
      p = Promise.all(promises);
    } else {
      p =  _loadURL(url);
    }
    p
      .then(val => {
        //check to see if we've suppressed this request.
        if (!suppress.get(requestID)) {
          resolve(val);
        }
      })
      .catch(error => {
        //check to see if we've suppressed this request.
        if (!suppress.get(requestID)) {
          reject(error);
        }
      });
    
  });
}

// Private loading function
function _loadURL(url) {
  let id = url;
  if (cache.has(id)) {
    return cache.get(id);
  } else {
    let extension = parseFileExtensionFromURL(url, loaders);
    let loader = loaders.get(extension);
    let p = loader(url);
    cache.set(id, p);
    return p;
  }
}

// Helpers

// Returns a filetype extension from a given url string
function parseFileExtensionFromURL(url, loaders) {
  const parts = url.split(".");
  const ext = parts[parts.length - 1];
  if (!loaders.has(ext)) {
    console.warn('Trying to load url: ' + url + ' with an unknown filetype. Assuming "text".');
  }
  return loaders.has(ext) ? ext : 'text';
}

// Export
export default load;